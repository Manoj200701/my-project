import React, { useState } from 'react';
import { Upload, Loader2, Leaf, AlertTriangle } from 'lucide-react';

interface DiagnosisResult {
  plantName: string;
  disease: string;
  confidence: number;
  symptoms: string[];
  treatment: string;
}

export default function PlantChecker() {
  const [image, setImage] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<DiagnosisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      setImage(URL.createObjectURL(selectedFile));
      setResult(null);
      setError(null);
    }
  };

  const analyzePlant = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);

    const formData = new FormData();
    formData.append('plantImage', file);

    try {
      // Point this to your live Railway Backend URL during production deployment
      const response = await fetch(process.env.REACT_APP_BACKEND_URL || 'http://localhost:5000/api/diagnose', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) throw new Error('Failed to analyze image.');
      
      const data = await response.json();
      setResult(data);
    } catch (err: any) {
      setError(err.message || 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col items-center p-6">
      <header className="flex items-center gap-2 mb-8 mt-4">
        <Leaf className="w-8 h-8 text-emerald-400" />
        <h1 className="text-2xl font-bold tracking-tight">Plant Disease AI Diagnostics</h1>
      </header>

      <main className="w-full max-w-xl bg-slate-800 border border-slate-700 rounded-2xl p-6 shadow-xl">
        {/* Upload Zone */}
        <div className="border-2 border-dashed border-slate-600 rounded-xl p-8 text-center flex flex-col items-center justify-center cursor-pointer hover:border-emerald-500 transition-colors relative">
          <input type="file" accept="image/*" onChange={handleImageChange} className="absolute inset-0 opacity-0 cursor-pointer" />
          {image ? (
            <img src={image} alt="Preview" className="max-h-48 rounded-lg object-cover" />
          ) : (
            <>
              <Upload className="w-10 h-10 text-slate-400 mb-3" />
              <p className="text-sm text-slate-300 font-medium">Drag & drop or click to upload leaf image</p>
            </>
          )}
        </div>

        {file && !loading && !result && (
          <button onClick={analyzePlant} className="w-full mt-5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-3 px-4 rounded-xl transition-all shadow-lg shadow-emerald-900/20">
            Analyze Plant Health
          </button>
        )}

        {/* Loading State */}
        {loading && (
          <div className="flex flex-col items-center justify-center py-8 gap-3">
            <Loader2 className="w-8 h-8 text-emerald-400 animate-spin" />
            <p className="text-sm text-slate-400 animate-pulse">Running computer vision sequence...</p>
          </div>
        )}

        {error && <div className="mt-4 p-4 bg-red-950/40 border border-red-800 text-red-400 rounded-xl text-sm">{error}</div>}

        {/* Precise Diagnosis Panel */}
        {result && (
          <div className="mt-6 border-t border-slate-700 pt-6 animate-fadeIn">
            <div className="flex items-center justify-between mb-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Target Crop</span>
                <h3 className="text-lg font-bold text-white">{result.plantName}</h3>
              </div>
              <div className="text-right">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">AI Confidence</span>
                <p className="text-md font-bold text-emerald-400">{result.confidence}%</p>
              </div>
            </div>

            <div className="p-4 bg-slate-850 border border-slate-700 rounded-xl flex items-start gap-3 mb-4">
              <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-semibold text-amber-400 uppercase">Exact Diagnosis</span>
                <h4 className="text-md font-bold text-white mt-0.5">{result.disease}</h4>
              </div>
            </div>

            <div className="mb-4">
              <h5 className="text-sm font-semibold text-slate-300 mb-1">Identified Symptoms:</h5>
              <ul className="list-disc list-inside text-sm text-slate-400 space-y-1">
                {result.symptoms.map((s, idx) => <li key={idx}>{s}</li>)}
              </ul>
            </div>

            <div className="p-4 bg-emerald-950/20 border border-emerald-900/50 rounded-xl">
              <h5 className="text-sm font-semibold text-emerald-400 mb-1">Recommended Treatment:</h5>
              <p className="text-sm text-slate-300">{result.treatment}</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
